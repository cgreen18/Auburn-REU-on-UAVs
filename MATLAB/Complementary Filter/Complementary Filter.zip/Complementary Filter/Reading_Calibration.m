clear all;
close all;
clc;

file_1 = 'calibration_ar174_flying_data.txt';
file_2 = 'calibration_ar174_flying_2_data.txt';

file_1_table = readtable(file_1);
file_2_table = readtable(file_2);

%time[1] : pitch[2] : roll[3] : yaw[4] : alt(demo)[5] : ...
%   Vx[6] : Vy[7] :Vz[8] : Mx[9] : My[10] : Mz[11] : ...
%   alt(vision)[12] : alt(raw)[13] : Ax[14] : Ay[15] : Az[16] ...
%   Wx[17] : Wy[18] : Wz[19]
file_1_data = table2array(file_1_table);
file_2_data = table2array(file_2_table);

total = [ file_1_data ; file_2_data ];

[ num_pts , num_sens ] = size(total);


means = mean(total);
stds = std(total);
variances = var(total);

dummy_x = 1:num_pts;

% % % % % % % % Plotting % % % % % % % %
%% Time
%close all;
time_fig = figure('NumberTitle', 'off', 'Name', 'Time');
plot(dummy_x , total(:,1));

%% Attitude
% pitch[2] : roll[3] : yaw[4]
%close all;

att_fig = figure('NumberTitle', 'off', 'Name', 'Attitude Estimation Line Graphs and Histograms');
set(att_fig,'Color','w');

%Pitch
subplot(2,3,1);
plot(dummy_x , total(:,2));
title("Pitch");
xlabel("Time [samples]");
ylabel("Estimated Pitch [deg.]");
xlim([0 , num_pts]);
set(gca,'FontSize',22);

subplot(2,3,4);
histogram(total(:,2),100000,'Normalization','probability','FaceColor',[0 0.4470 0.7410],'EdgeColor',[0 0.4470 0.7410]);
xlabel("Estimated Pitch [deg.]");
ylabel("Relative Frequency");
xlim([-.2 , .1]);
set(gca,'FontSize',22);

%Roll
subplot(2,3,2);
plot(dummy_x , total(:,3));
title("Roll");
xlabel("Time [samples]");
ylabel("Estimated Roll [deg.]");
xlim([0 , num_pts]);
set(gca,'FontSize',22);

subplot(2,3,5);
histogram(total(:,3),100000,'Normalization','probability','FaceColor',[0 0.4470 0.7410],'EdgeColor',[0 0.4470 0.7410]);
xlabel("Estimated Roll [deg.]");
ylabel("Relative Frequency");
xlim([-.1 , .1]);
set(gca,'FontSize',22);

%Yaw
subplot(2,3,3);
plot(dummy_x , total(:,4));
title("Yaw");
xlabel("Time [samples]");
ylabel("Estimated Yaw [deg.]");
xlim([0 , num_pts]);
ylim([173.5 , 174.4]);
set(gca,'FontSize',22);

subplot(2,3,6);
histogram(total(:,4),100000,'Normalization','probability','FaceColor',[0 0.4470 0.7410],'EdgeColor',[0 0.4470 0.7410]);
xlabel("Estimated Yaw [deg.]");
ylabel("Relative Frequency");
xlim([ 173.6 , 174.3]);
set(gca,'FontSize',22);


%% Velocities
% Vx[6] : Vy[7] :Vz[8]
%close all;

vel_fig = figure('NumberTitle', 'off', 'Name', 'Velocity Estimation in XYZ Line Graphs and Histograms');
set(vel_fig,'Color','w');

%Vx
subplot(2,3,1);
plot(dummy_x , total(:,6));
title("V_x");
xlabel("Time [samples]");
ylabel("Estimated Velocity (mm/s)");
xlim([0 , num_pts]);
set(gca,'FontSize',22);

subplot(2,3,4);
histogram(total(:,6),100000,'Normalization','probability','FaceColor',[0 0.4470 0.7410],'EdgeColor',[0 0.4470 0.7410]);
xlabel("Estimated Velocity (mm/s)");
ylabel("Frequency");
xlim([5, 20]);
set(gca,'FontSize',22);

%Vy
subplot(2,3,2);
plot(dummy_x , total(:,7));
title("V_y");
xlabel("Time [samples]");
ylabel("Estimated Velocity (mm/s)");
xlim([0 , num_pts]);
set(gca,'FontSize',22);

subplot(2,3,5);
histogram(total(:,7),100000,'Normalization','probability','FaceColor',[0 0.4470 0.7410],'EdgeColor',[0 0.4470 0.7410]);
xlabel("Estimated Velocity (mm/s)");
ylabel("Frequency");
xlim([-10, 10]);
set(gca,'FontSize',22);

%Vz
subplot(2,3,3);
plot(dummy_x , total(:,8));
title("V_z (Broken)");
xlabel("Time [samples]");
ylabel("Estimated Velocity (mm/s)");
xlim([0 , num_pts]);
ylim([-.6 , .6]);
set(gca,'FontSize',22);

subplot(2,3,6);
histogram(total(:,8),100000,'Normalization','probability','FaceColor',[0 0.4470 0.7410],'EdgeColor',[0 0.4470 0.7410]);
xlabel("Estimated Velocity (mm/s)");
ylabel("Frequency");
xlim([-.1,.1]);
set(gca,'FontSize',22);


%% Magnetometer Readings
% Mx[9] : My[10] : Mz[11]
%close all;

mag_fig = figure('NumberTitle', 'off', 'Name', 'Magnetometer Sensor Line Graphs and Histograms');
set(mag_fig,'Color','w');

%Mx
subplot(2,3,1);
plot(dummy_x , total(:,9));
title("M_x");
xlabel("Time [samples]");
ylabel("Magnetic Induction [mT]");
xlim([0 , num_pts]);
ylim([-40 60]);
set(gca,'FontSize',22);

subplot(2,3,4);
histogram(total(:,9),100000,'Normalization','probability','FaceColor',[0 0.4470 0.7410],'EdgeColor',[0 0.4470 0.7410]);
xlabel("Magnetic Induction [mT]");
ylabel("Frequency");
set(gca,'FontSize',22);


%My
subplot(2,3,2);
plot(dummy_x , total(:,10));
title("M_y");
xlabel("Time [samples]");
ylabel("Magnetic Induction [mT]");
xlim([0 , num_pts]);
ylim([10 , 110]);
set(gca,'FontSize',22);

subplot(2,3,5);
histogram(total(:,10),100000,'Normalization','probability','FaceColor',[0 0.4470 0.7410],'EdgeColor',[0 0.4470 0.7410]);
xlabel("Magnetic Induction [mT]");
ylabel("Frequency");
set(gca,'FontSize',22);


%Mz
subplot(2,3,3);
plot(dummy_x , total(:,11));
title("M_z");
xlabel("Time [samples]");
ylabel("Magnetic Induction [mT]");
xlim([0 , num_pts]);
ylim([180 , 280]);
set(gca,'FontSize',22);

subplot(2,3,6);
histogram(total(:,11),100000,'Normalization','probability','FaceColor',[0 0.4470 0.7410],'EdgeColor',[0 0.4470 0.7410]);
xlabel("Magnetic Induction [mT]");
ylabel("Frequency");
set(gca,'FontSize',22);

%% Altitude Readings
% alt(demo)[5] : alt(vision)[12] : alt(raw)[13]
%close all;

alt_fig = figure('NumberTitle', 'off', 'Name', 'Various Altitude Line Graphs and Histograms');
set(alt_fig,'Color','w');

%alt1
subplot(2,3,1);
alt1 = total(:,5) * 10;
plot(dummy_x , alt1);
title("Alt (demo)");
xlabel("Time [samples]");
ylabel("Estimated Altitude [mm]");
xlim([0 , num_pts]);
set(gca,'FontSize',22);

subplot(2,3,4);
histogram(alt1,100000,'Normalization','probability','FaceColor',[0 0.4470 0.7410],'EdgeColor',[0 0.4470 0.7410]);
xlabel("Estimated Altitude [mm]");
ylabel("Relative Frequency");
xlim([550 , 700]);
set(gca,'FontSize',22);

%alt2
subplot(2,3,2);
plot(dummy_x , total(:,12));
title("Alt (Vision)");
xlabel("Time [samples]");
ylabel("Estimated Altitude [mm]");
xlim([0 , num_pts]);
set(gca,'FontSize',22);

subplot(2,3,5);
histogram(total(:,12),100000,'Normalization','probability','FaceColor',[0 0.4470 0.7410],'EdgeColor',[0 0.4470 0.7410]);
xlabel("Estimated Altitude [mm]");
ylabel("Relative Frequency");
xlim([280 , 380]);
set(gca,'FontSize',22);


%alt3
subplot(2,3,3);
plot(dummy_x , total(:,13));
title("Alt (Raw)");
xlabel("Time [samples]");
ylabel("Measured Altitude [mm]");
xlim([0 , num_pts]);
set(gca,'FontSize',22);

subplot(2,3,6);
histogram(total(:,13),100000,'Normalization','probability','FaceColor',[0 0.4470 0.7410],'EdgeColor',[0 0.4470 0.7410]);
xlabel("Measured Altitude [mm]");
ylabel("Relative Frequency");
xlim([340 , 346]);
set(gca,'FontSize',22);

%% Accelerometer Readings
% Ax[14] : Ay[15] : Az[16]
%close all;

acc_fig = figure('NumberTitle', 'off', 'Name', 'Accelerometer Sensor Line Graphs and Histograms');
set(acc_fig,'Color','w');

% Trying to normalize

% Ax Ay Az
% After converting from LSB into G and removing gravity (Az=1), determined mean
acc_bias =  [0.0949 , -0.0324, 0.007];

accel_no_grav = (total(:, 14:16) - 2048) / 512;

accel_no_grav = accel_no_grav - acc_bias;
accel_no_grav(:,3) = -accel_no_grav(:,3) + 1;

%Ax
subplot(2,3,1);
Ax = accel_no_grav(:,1);
plot(dummy_x , Ax);
title("a_x");
xlabel("Time [samples]");
ylabel("Acceleration [mG]");
xlim([0 , num_pts]);
ylim([-1 , 1]);
set(gca,'FontSize',22);

subplot(2,3,4);
histogram(Ax,100000,'Normalization','probability','FaceColor',[0 0.4470 0.7410],'EdgeColor',[0 0.4470 0.7410]);
xlabel("Acceleration [mG]");
ylabel("Relative Frequency");
xlim([-1 , 1]);
set(gca,'FontSize',22);

disp("mean of Ax")
mean(Ax)

%Ay
subplot(2,3,2);
Ay = accel_no_grav(:,2);
plot(dummy_x , Ay);
title("a_y");
xlabel("Time [samples]");
ylabel("Acceleration [mG]");
xlim([0 , num_pts]);
set(gca,'FontSize',22);

subplot(2,3,5);
histogram(Ay,100000,'Normalization','probability','FaceColor',[0 0.4470 0.7410],'EdgeColor',[0 0.4470 0.7410]);
xlabel("Acceleration [mG]");
ylabel("Relative Frequency");
xlim([-.5 , .5]);
set(gca,'FontSize',22);

disp("mean of Ay")
mean(Ay)

%Az
subplot(2,3,3);
Az = accel_no_grav(:,3);
plot(dummy_x ,Az);
title("a_z");
xlabel("Time [samples]");
ylabel("Acceleration [mG]");
xlim([0 , num_pts]);
set(gca,'FontSize',22);


subplot(2,3,6);
histogram(Az,100000,'Normalization','probability','FaceColor',[0 0.4470 0.7410],'EdgeColor',[0 0.4470 0.7410]);
xlabel("Acceleration [mG]");
ylabel("Relative Frequency");
xlim([-.5 , .5]);
set(gca,'FontSize',22);


%% Gyroscope Readings
% Wx[17] : Wy[18] : Wz[19]
%close all;

acc_fig = figure('NumberTitle', 'off', 'Name', 'Gyroscope Sensor Line Graphs and Histograms');
set(acc_fig,'Color','w');

%Wx
subplot(2,3,1);
plot(dummy_x , total(:,17));
title("\omega_x (Roll)");
xlabel("Time [samples]");
ylabel("Angular Velocity [deg/s]");
xlim([0 , num_pts]);
set(gca,'FontSize',22);

subplot(2,3,4);
histogram(total(:,17),1000,'Normalization','probability','FaceColor',[0 0.4470 0.7410],'EdgeColor',[0 0.4470 0.7410]);
xlabel("Angular Velocity [deg/s]");
ylabel("Relative Frequency");
xlim([18,42]);
set(gca,'FontSize',22);

%Wy
subplot(2,3,2);
plot(dummy_x , total(:,18));
title("\omega_y (Pitch)");
xlabel("Time [samples]");
ylabel("Angular Velocity [deg/s]");
xlim([0 , num_pts]);
set(gca,'FontSize',22);

subplot(2,3,5);
histogram(total(:,18),1000,'Normalization','probability','FaceColor',[0 0.4470 0.7410],'EdgeColor',[0 0.4470 0.7410]);
xlabel("Angular Velocity [deg/s]");
ylabel("Relative Frequency");
xlim([44 , 78]);
set(gca,'FontSize',22);

%Wz
subplot(2,3,3);
plot(dummy_x ,total(:,19));
title("\omega_z (Yaw)");
xlabel("Time [samples]");
ylabel("Angular Velocity [deg/s]");
xlim([0 , num_pts]);
set(gca,'FontSize',22);


subplot(2,3,6);
histogram(total(:,19),1000,'Normalization','probability','FaceColor',[0 0.4470 0.7410],'EdgeColor',[0 0.4470 0.7410]);
xlabel("Angular Velocity [deg/s]");
ylabel("Relative Frequency");
xlim([-22 , -8]);
set(gca,'FontSize',22);

